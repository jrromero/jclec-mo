package net.sf.jclec.mo.problem.wrm;


import org.apache.commons.lang.builder.EqualsBuilder;
import org.apache.commons.lang.builder.HashCodeBuilder;
import org.apache.commons.lang.builder.ToStringBuilder;

import net.sf.jclec.IFitness;
import net.sf.jclec.IIndividual;
import net.sf.jclec.mo.IConstrained;
import net.sf.jclec.pso.Particle;
import net.sf.jclec.realarray.RealArrayIndividual;

/**
 * This class represents a candidate solution of the Water 
 * Resource Management (WRM) optimization problem.
 * 
 * <p>HISTORY:
 * <ul>
 *	<li>(AR|JRR|SV, 1.0, November 2017)		Initial version.</li>
 * </ul>
 * </p>
 * 
 * @version 1.0
 * 
 * @author Aurora Ramirez (AR)
 * @author Jose Raul Romero (JRR)
 * @author Sebastian Ventura (SV)
 * 
 * <p>Knowledge Discovery and Intelligent Systems (KDIS) Research Group: 
 * {@link http://www.uco.es/grupos/kdis}</p>
 * 
 * @see Particle
 * @see RealArrayIndividual
 * @see IConstrained
 * */

public class WRMSolution extends Particle implements IConstrained {

	/////////////////////////////////////////////////////////////////
	// --------------------------------------------------- Properties
	/////////////////////////////////////////////////////////////////

	/** Serial ID */
	private static final long serialVersionUID = -6243708956198387307L;

	/** The solution is feasible */
	boolean isFeasible;

	/** The degree of infeasibility */
	double degreeOfInfeasibility;

	/////////////////////////////////////////////////////////////////
	// ------------------------------------------------- Constructors
	/////////////////////////////////////////////////////////////////

	/**
	 * Empty constructor.
	 */
	public WRMSolution() {
		super();
	}
	
	/**
	 * Parameterized constructor. 
	 * @param solution Individual genotype / Particle position.
	 */
	public WRMSolution(double[] solution) {
		super(solution);
	}

	/**
	 * Parameterized constructor.
	 * @param solution Individual genotype / Particle position.
	 * @param fitness Fitness of the solution.
	 */
	public WRMSolution(double[] solution, IFitness fitness) {
		super(solution, fitness);
	}

	/**
	 * Parameterized constructor.
	 * @param solution Individual genotype / Particle position.
	 * @param fitness  The fitness of the solution.
	 * @param velocity Particle velocity.
	 */
	public WRMSolution(double[] solution, IFitness fitness, double [] velocity) {
		super(solution, fitness, velocity);
	}
	
	/////////////////////////////////////////////////////////////////
	// --------------------------------------------- Override methods
	/////////////////////////////////////////////////////////////////

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public boolean isFeasible() {
		return this.isFeasible;
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public void setFeasible(boolean feasible) {
		this.isFeasible = feasible;
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public double degreeOfInfeasibility() {
		return this.degreeOfInfeasibility;
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public void setDegreeOfInfeasibility(double degree) {
		this.degreeOfInfeasibility = degree;
	}

	/////////////////////////////////////////////////////////////////
	// ------------------------------------------------- Constructors
	/////////////////////////////////////////////////////////////////

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public IIndividual copy() {
		WRMSolution other = new WRMSolution();
		int size = this.genotype.length;

		// Create a copy of the position array
		double [] genotype = new double[size];
		System.arraycopy(this.genotype, 0, genotype, 0, size);
		other.setGenotype(genotype);

		// Create a copy of the velocity array
		if(this.velocity != null){
			double [] otherVelocity = new double[size];
			System.arraycopy(this.velocity, 0, otherVelocity, 0, size);
			other.setVelocity(otherVelocity);
		}
		
		// Create a copy of the best position
		if(this.bestPosition != null){
			double [] otherBest = new double[size];
			System.arraycopy(this.bestPosition, 0, otherBest, 0, size);
			other.setBestPosition(otherBest);
		}
		
		// Copy the fitness
		if (this.fitness != null) {
			other.setFitness(this.fitness.copy());
		}

		// Copy the best fitness
		if(this.bestFitness != null){
			other.setBestFitness(this.bestFitness.copy());
		}
		
		// Copy constraint properties
		other.setFeasible(this.isFeasible);
		other.setDegreeOfInfeasibility(this.degreeOfInfeasibility);
		
		return other;
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public boolean equals(Object other) {
		if (other instanceof WRMSolution) {
			WRMSolution otherSolution = (WRMSolution) other;
			EqualsBuilder eb = new EqualsBuilder();
			eb.append(this.genotype, otherSolution.genotype);
			eb.append(this.velocity, otherSolution.velocity);
			eb.append(this.bestPosition, otherSolution.bestPosition);
			eb.append(this.bestFitness, otherSolution.bestFitness);
			eb.append(this.isFeasible, otherSolution.isFeasible);
			eb.append(this.degreeOfInfeasibility, otherSolution.degreeOfInfeasibility);
			return eb.isEquals();
		}
		else {
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public int hashCode() {
		// Hash code builder
		HashCodeBuilder hcb = new HashCodeBuilder();

		// Append super-hashCode
		hcb.appendSuper(super.hashCode());

		// Append specific properties
		hcb.append(this.velocity);
		hcb.append(this.bestPosition);
		hcb.append(this.bestFitness);
		hcb.append(this.isFeasible);
		hcb.append(this.degreeOfInfeasibility);

		// Return hash code
		return hcb.toHashCode();
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public String toString(){
		ToStringBuilder tsb = new ToStringBuilder(this);
		tsb.append("decision variables", genotype);
		tsb.append("fitness", fitness);
		return tsb.toString();
	}
}
