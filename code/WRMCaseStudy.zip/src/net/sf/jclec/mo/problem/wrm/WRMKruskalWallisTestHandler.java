package net.sf.jclec.mo.problem.wrm;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import es.uco.kdis.datapro.algorithm.wrappers.r.tests.RKruskal;
import es.uco.kdis.datapro.dataset.Dataset;
import es.uco.kdis.datapro.dataset.source.CsvDataset;
import net.sf.jclec.mo.experiment.handler.MOExperimentHandler;

/**
 * An customized handler to execute the Kruskal-Wallis statistical test
 * for each of the quality indicators computed in the experiment.
 * 
 * <p>HISTORY:
 * <ul>
 *	<li>(AR|JRR|SV, 1.0, September 2018)		Initial version.</li>
 * </ul>
 * </p>
 * 
 * @version 1.0
 * 
 * @author Aurora Ramirez (AR)
 * @author Jose Raul Romero (JRR)
 * @author Sebastian Ventura (SV)
 * 
 * <p>Knowledge Discovery and Intelligent Systems (KDIS) Research Group: 
 * {@link http://www.uco.es/grupos/kdis}</p>
 * 
 * */

public class WRMKruskalWallisTestHandler extends MOExperimentHandler {

	/** The name of the files containing the results */
	protected String [] resultFileNames;

	/** The list of indicator results to be used */
	protected List<Dataset> indicatorResults;

	/** The number of algorithms to compare */
	protected int numAlgorithms;

	/** The object containing the result for each test */
	protected List<Map<String,Object>> testResults;

	/////////////////////////////////////////////////////////////////
	// ------------------------------------------------- Constructors
	/////////////////////////////////////////////////////////////////

	/**
	 * Parameterized constructor.
	 * @param directoryName The path to the general reporting directory.
	 * @param resultFileNames The names of the files containing the results of the indicators.
	 * @param numAlgorithms Number of algorithms to be compared.
	 * */
	public WRMKruskalWallisTestHandler(String directoryName, String [] resultFileNames, int numAlgorithms) {
		super(directoryName);
		this.resultFileNames = resultFileNames;
		this.numAlgorithms = numAlgorithms;
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public void process() {
		readDatasets();
		computeTests();
		saveResults();
		if(nextHandler()!=null)
			nextHandler().process();
	}

	/**
	 * Read the result files as CSV datasets
	 * */
	protected void readDatasets() {

		File dataFile;
		Dataset dataset = null;
		String format = new String(""); //Each column is an algorithm
		for(int i=0; i<this.numAlgorithms; i++){
			format+="f";
		}

		// Check if the handler can be processed
		if(this.directory.exists() && this.directory.isDirectory()){
			this.indicatorResults = new ArrayList<Dataset>();

			for(int i=0; i<this.resultFileNames.length; i++){

				// Check that the file exists and try to open it as CSV dataset
				dataFile = new File(this.directory.getAbsolutePath() + "/" + this.resultFileNames[i]); 
				if(dataFile.exists()){

					dataset = new CsvDataset(dataFile.getAbsolutePath());
					try{
						((CsvDataset)dataset).readDataset("nv", format);
						dataset.setName(this.resultFileNames[i]);
						this.indicatorResults.add(dataset);
					}catch(Exception e){
						e.printStackTrace();
					}
				}
			}
		}
	}

	/**
	 * Compute the test for each indicator
	 * */
	protected void computeTests() {

		RKruskal algorithm;
		this.testResults = new ArrayList<Map<String,Object>>();
		for(int i=0; i<this.indicatorResults.size(); i++) {
			// Execute the test for each indicator
			algorithm = new RKruskal(this.indicatorResults.get(i),"myData",false);
			algorithm.initialize();
			algorithm.execute();
			algorithm.postexec();

			// Get the result
			@SuppressWarnings("unchecked")
			Map<String,Object> testMapResult = (Map<String,Object>)algorithm.getResult();
			this.testResults.add(testMapResult);
		}
	}

	/**
	 * Save the result in a text file. The output directory is "tests".
	 * */
	protected void saveResults() {

		FileWriter writer;
		Iterator<String> keys;
		StringBuffer sb;
		Map<String,Object> testMapResult;
		String reportDir = this.getExperimentReportDirectory() + "/tests";
		String filename, indicatorName;

		// Create output folder
		File outDir = new File(reportDir);
		if(!outDir.exists())
			outDir.mkdirs();

		// Process the output of the tests
		for(int i=0; i<this.testResults.size(); i++) {

			// Get the result
			testMapResult = this.testResults.get(i);
			keys = testMapResult.keySet().iterator();

			// Get the test information
			sb = new StringBuffer();
			sb.append("Input file: " + this.resultFileNames[i]+"\n");
			sb.append("Statistical test: Kruskal-Wallis\n");

			while(keys.hasNext()){
				String key = keys.next();
				Object value = testMapResult.get(key);
				sb.append(key+": "+value + "\n");
			}

			// Write in a new file
			indicatorName =  this.resultFileNames[i].substring(this.resultFileNames[i].indexOf("/")+1, this.resultFileNames[i].lastIndexOf("-"));
			filename = reportDir + "/kruskall-" + indicatorName + ".txt"; 
			try {
				writer = new FileWriter(filename);
				writer.write(sb.toString());
				writer.close();
			}catch(IOException e) {
				e.printStackTrace();
			}
		}
	}
}
