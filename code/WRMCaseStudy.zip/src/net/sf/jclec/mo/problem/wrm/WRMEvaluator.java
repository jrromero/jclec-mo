package net.sf.jclec.mo.problem.wrm;


import net.sf.jclec.IIndividual;
import net.sf.jclec.mo.IConstrained;
import net.sf.jclec.mo.evaluation.MOEvaluator;
import net.sf.jclec.realarray.RealArrayIndividual;

/**
 * This class represents the evaluator for the Water 
 * Resource Management (WRM) optimization problem.
 * 
 * <p>HISTORY:
 * <ul>
 *	<li>(AR|JRR|SV, 1.0, November 2017)		Initial version.</li>
 * </ul>
 * </p>
 * 
 * @version 1.0
 * 
 * @author Aurora Ramirez (AR)
 * @author Jose Raul Romero (JRR)
 * @author Sebastian Ventura (SV)
 * 
 * <p>Knowledge Discovery and Intelligent Systems (KDIS) Research Group: 
 * {@link http://www.uco.es/grupos/kdis}</p>
 * 
 * @see MOEvaluator
 * */
public class WRMEvaluator extends MOEvaluator {

	/////////////////////////////////////////////////////////////////
	// --------------------------------------------------- Properties
	/////////////////////////////////////////////////////////////////

	/** Serial ID */
	private static final long serialVersionUID = 5445842327492028906L;

	/////////////////////////////////////////////////////////////////
	// ------------------------------------------------- Constructors
	/////////////////////////////////////////////////////////////////

	/**
	 * Empty constructor.
	 * */
	public WRMEvaluator(){
		super();
	}

	/////////////////////////////////////////////////////////////////
	// --------------------------------------------- Override methods
	/////////////////////////////////////////////////////////////////

	/**
	 * {@inheritDoc}
	 * */
	@Override
	protected void evaluate(IIndividual solution) {

		// Call super implementation (evaluate objective functions)
		super.evaluate(solution);

		// Check constraints
		double [] genotype = ((RealArrayIndividual)solution).getGenotype();
		double x1 = genotype[0], x2 = genotype[1], x3 = genotype[2];

		double [] g = new double[7];
		g[0] = (0.00139/(x1*x2)+4.94*x3-0.08) - 1; 				// g1
		g[1] = (0.000306/(x1*x2)+1.082*x3-0.0986) - 1;			// g2
		g[2] = (12.307/(x1*x2)+49408.24*x3+4051.02) - 50000;	// g3
		g[3] = (2.098/(x1*x2)+8046.33*x3-696.71) - 1600;		// g4
		g[4] = (2.138/(x1*x2)+7883.39*x3-705.04) - 10000;		// g5
		g[5] = (0.417/(x1*x2)+1721.26*x3-136.54) - 2000;		// g6
		g[6] = (0.164/(x1*x2)+631.13*x3-54.48) - 550;			// g7
		double total = 0.0;

		// Compute the degree of constraint violation
		for(int i=0; i<7; i++){
			if(g[i] > 0){
				total += g[i];
			}
		}

		// Set the feasibility properties
		if(total > 0){
			((IConstrained)solution).setFeasible(false);
		}
		else{
			((IConstrained)solution).setFeasible(true);
		}
		((IConstrained)solution).setDegreeOfInfeasibility(total);
	}
}
