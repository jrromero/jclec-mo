package net.sf.jclec.mo.problem.wrm;


import org.apache.commons.lang.builder.EqualsBuilder;

import net.sf.jclec.pso.Particle;
import net.sf.jclec.pso.ParticleSpecies;
import net.sf.jclec.realarray.RealArrayIndividual;
import net.sf.jclec.util.range.IRange;

/**
 * This class represents the species of the Water 
 * Resource Management (WRM) optimization problem.
 * 
 * <p>HISTORY:
 * <ul>
 *	<li>(AR|JRR|SV, 1.0, November 2017)		Initial version.</li>
 * </ul>
 * </p>
 * 
 * @version 1.0
 * 
 * @author Aurora Ramirez (AR)
 * @author Jose Raul Romero (JRR)
 * @author Sebastian Ventura (SV)
 * 
 * <p>Knowledge Discovery and Intelligent Systems (KDIS) Research Group: 
 * {@link http://www.uco.es/grupos/kdis}</p>
 * 
 * @see ParticleSpecies
 * @see WRMSolution
 * */

public class WRMSolutionSpecies extends ParticleSpecies {

	/////////////////////////////////////////////////////////////////
	// --------------------------------------------------- Properties
	/////////////////////////////////////////////////////////////////

	/** Serial ID */
	private static final long serialVersionUID = -1648915512001407289L;

	/////////////////////////////////////////////////////////////////
	// ------------------------------------------------- Constructors
	/////////////////////////////////////////////////////////////////

	/**
	 * Empty constructor.
	 * */
	public WRMSolutionSpecies() {
		super();
	}

	/**
	 * Parameterized constructor.
	 * @param schema The solution schema.
	 */
	public WRMSolutionSpecies(IRange [] schema) {
		super(schema);
	}

	/////////////////////////////////////////////////////////////////
	// --------------------------------------------- Override methods
	/////////////////////////////////////////////////////////////////

	/**
	 * {@inheritDoc}
	 */
	@Override
	public RealArrayIndividual createIndividual() {
		return new WRMSolution();
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public RealArrayIndividual createIndividual(double[] position) {
		return new WRMSolution(position);
	}

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object other) {
		if (other instanceof WRMSolutionSpecies) {
			EqualsBuilder eb = new EqualsBuilder();
			WRMSolutionSpecies otherSpecies = (WRMSolutionSpecies) other;
			eb.append(this.genotypeSchema, otherSpecies.genotypeSchema);
			return eb.isEquals();
		}
		else {
			return false;
		}
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public Particle createParticle() {
		return new WRMSolution();
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public Particle createParticle(double[] position) {
		return new WRMSolution(position);
	}

	/**
	 * {@inheritDoc}
	 * */
	@Override
	public Particle createParticle(double[] position, double [] velocity) {
		return new WRMSolution(position);
	}
}
