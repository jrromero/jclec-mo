package net.sf.jclec.mo.problem.wrm;


import java.util.ArrayList;
import java.util.List;

import net.sf.jclec.mo.experiment.MOExperiment;
import net.sf.jclec.mo.experiment.MOExperimentRunner;
import net.sf.jclec.mo.experiment.handler.ComputeIndicators;
import net.sf.jclec.mo.experiment.handler.GenerateAlgorithmPF;
import net.sf.jclec.mo.experiment.handler.GenerateIndicatorBoxPlots;
import net.sf.jclec.mo.experiment.handler.GenerateParallelPlots;
import net.sf.jclec.mo.experiment.handler.GenerateReferencePF;
import net.sf.jclec.mo.experiment.handler.MOExperimentHandler;
import net.sf.jclec.mo.experiment.handler.ScaleAlgorithmPF;
import net.sf.jclec.mo.indicator.AdditiveEpsilon;
import net.sf.jclec.mo.indicator.Epsilon;
import net.sf.jclec.mo.indicator.GeneralizedSpread;
import net.sf.jclec.mo.indicator.GenerationalDistance;
import net.sf.jclec.mo.indicator.Indicator;
import net.sf.jclec.mo.indicator.InvertedGenerationalDistance;
import net.sf.jclec.mo.indicator.MaximumError;

/**
 * An experiment to solve the Water Resource Management (WRM) 
 * optimization problem using JCLEC-MO.
 * 
 * <p>HISTORY:
 * <ul>
 *	<li>(AR|JRR|SV, 1.0, November 2017)		Initial version.</li>
 * </ul>
 * </p>
 * 
 * @version 1.0
 * 
 * @author Aurora Ramirez (AR)
 * @author Jose Raul Romero (JRR)
 * @author Sebastian Ventura (SV)
 * 
 * <p>Knowledge Discovery and Intelligent Systems (KDIS) Research Group: 
 * {@link http://www.uco.es/grupos/kdis}</p>
 * 
 * */
public class WRMCaseStudy {

	public static void main(String [] args){

		// MO experiment
		MOExperiment myExperiment = new MOExperiment();
		myExperiment.addConfigurationsFromDirectory("configuration-files/");
		
		// JCLEC-MOEA runner
		MOExperimentRunner runner = new MOExperimentRunner();
		for(int i=0; i<myExperiment.getNumberOfConfigurations(); i++){
			runner.executeSequentially(myExperiment.getConfiguration(i));
		}

		// Post-processing outcomes
		boolean [] mop = new boolean[]{false,false,false,false,false}; // 5 objectives to be minimized
		String reportDirectory = "./reports/WRMExperiment";
		double minValues [] = new double[]{63840.2774,30.0,0.28534689,183749.9670692,741.622222221};
		double maxValues [] = new double[]{83060.744,1350.0,2.85346895,16027735.33304959,347469.4};
		List<Indicator> indicators = new ArrayList<Indicator>();
		indicators.add(new AdditiveEpsilon());
		indicators.add(new Epsilon());
		indicators.add(new GeneralizedSpread());
		indicators.add(new GenerationalDistance());
		indicators.add(new InvertedGenerationalDistance());
		indicators.add(new MaximumError());
		
		// Create the handlers
		MOExperimentHandler handler1 = new GenerateAlgorithmPF(reportDirectory,mop);
		MOExperimentHandler handler2 = new GenerateReferencePF(reportDirectory,mop);
		MOExperimentHandler handler3 = new ScaleAlgorithmPF(reportDirectory, mop, minValues, maxValues);
		MOExperimentHandler handler5 = new GenerateIndicatorBoxPlots(reportDirectory, 4, 7);
		MOExperimentHandler handler4 = new GenerateParallelPlots(reportDirectory, true, 5, 7);
		MOExperimentHandler handler6 = new ComputeIndicators(reportDirectory, indicators, 5, null, true);
		String [] indicatorFileNames = {"indicators/Hypervolume-final.csv", "indicators/Spacing-final.csv"};
		MOExperimentHandler handler7 = new WRMKruskalWallisTestHandler(reportDirectory, indicatorFileNames, 4);
		
		// Create the chain of handlers
		handler1.setSuccessor(handler2);
		handler2.setSuccessor(handler3);
		handler3.setSuccessor(handler4);
		handler4.setSuccessor(handler5);
		handler5.setSuccessor(handler6);
		handler6.setSuccessor(handler7);
		
		// Execute the complete post-processing
		handler1.process();
	}
}
